def main():
    num_vertices, num_edges = map(int, input("Enter the number of vertices (N) and edges (M): ").split())
    vertex_degrees = [0] * num_vertices
    edge_types = [-1] * num_edges

    print("Initial vertex degrees:", vertex_degrees)
    print("Initial edge types:", edge_types)

    if num_edges % 2 != 0 and num_vertices % 2 != 0:
        print("Graph is not valid: Odd number of edges and odd number of vertices.")
    else:
        for i in range(num_edges):
            vertex_u, vertex_v = map(int, input(f"Enter the vertices for edge {i + 1}: ").split())
            if vertex_degrees[vertex_u - 1] % 2 == 0 and vertex_degrees[vertex_v - 1] % 2 == 0:
                edge_types[i] = 0
                vertex_degrees[vertex_v - 1] += 1
            elif vertex_degrees[vertex_u - 1] % 2 != 0 and vertex_degrees[vertex_v - 1] % 2 == 0:
                edge_types[i] = 1
                vertex_degrees[vertex_u - 1] += 1
            elif vertex_degrees[vertex_u - 1] % 2 == 0 and vertex_degrees[vertex_v - 1] % 2 != 0:
                vertex_degrees[vertex_v - 1] += 1
                edge_types[i] = 1

        for degree in vertex_degrees:
            if degree % 2 != 0:
                print("Graph is not valid: There's a vertex with an odd degree.")
                exit(0)

        print("Final edge types:", edge_types)

if __name__ == "__main__":
    main()
