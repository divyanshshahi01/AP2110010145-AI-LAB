def can_finish(num_tasks, prerequisites):
    dependency_graph = [[] for _ in range(num_tasks)]
    visited_nodes = [False] * num_tasks
    in_degrees = [0] * num_tasks
    start_task = -1
    
    for prereq in prerequisites:
        task, dependency = prereq
        dependency_graph[dependency].append(task)
        in_degrees[task] += 1
    
    for i in range(num_tasks):
        if in_degrees[i] == 0:
            start_task = i
    
    if start_task == -1:
        return False
    else:
        def depth_first_search(node):
            visited_nodes[node] = True
            for neighbor in dependency_graph[node]:
                if not visited_nodes[neighbor]:
                    if not depth_first_search(neighbor):
                        return False
                else:
                    return False
            return True
    
    return depth_first_search(start_task)

print(can_finish(4, [[0, 1], [1, 2], [2, 3], [3, 0]])) 
print(can_finish(5, [[0, 1], [1, 2], [2, 3], [3, 4]]))
print(can_finish(3, [[0, 1], [1, 2], [2, 0]]))
print(can_finish(6, [[1, 0], [2, 1], [3, 2], [4, 3], [5, 4], [0, 5]])) 
print(can_finish(3, [[1, 0], [2, 1], [0, 2]]))  
